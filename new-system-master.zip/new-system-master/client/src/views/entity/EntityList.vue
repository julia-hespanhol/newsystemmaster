<template>
    <VContainer>
        <EntityTable />
    </VContainer>
</template>

<script>

import EntityTable from '../../components/EntityTable.vue';

export default {
    name: 'EntityList',
    components: {
        EntityTable,
    },
};
</script>

<style scoped>
</style>
